var searchData=
[
  ['self_5fkill_35',['self_kill',['../process_8cpp.html#a547fb733d2e415df3a842bf5741b2ec5',1,'process.cpp']]],
  ['self_5fkill_5fhard_36',['self_kill_hard',['../process_8cpp.html#a8204915df125e9160dad997f5c55ec5f',1,'process.cpp']]]
];
