var searchData=
[
  ['self_5fkill_15',['self_kill',['../process_8cpp.html#a547fb733d2e415df3a842bf5741b2ec5',1,'process.cpp']]],
  ['self_5fkill_5fhard_16',['self_kill_hard',['../process_8cpp.html#a8204915df125e9160dad997f5c55ec5f',1,'process.cpp']]],
  ['signal_17',['signal',['../process__out_8txt.html#a2763b8db23e691d2b56c35078a363009',1,'process_out.txt']]],
  ['signal_5fchild_5fdeath_18',['SIGNAL_CHILD_DEATH',['../process_8cpp.html#a661de116e4c095c28be59c7f9334d7a1',1,'SIGNAL_CHILD_DEATH():&#160;process.cpp'],['../watchdog_8cpp.html#a661de116e4c095c28be59c7f9334d7a1',1,'SIGNAL_CHILD_DEATH():&#160;watchdog.cpp']]],
  ['signal_5fkillself_19',['SIGNAL_KILLSELF',['../process_8cpp.html#a0f1ffd6add45a57cb80935542feabfdd',1,'SIGNAL_KILLSELF():&#160;process.cpp'],['../watchdog_8cpp.html#a0f1ffd6add45a57cb80935542feabfdd',1,'SIGNAL_KILLSELF():&#160;watchdog.cpp']]]
];
