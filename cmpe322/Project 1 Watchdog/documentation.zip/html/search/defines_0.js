var searchData=
[
  ['signal_5fchild_5fdeath_50',['SIGNAL_CHILD_DEATH',['../process_8cpp.html#a661de116e4c095c28be59c7f9334d7a1',1,'SIGNAL_CHILD_DEATH():&#160;process.cpp'],['../watchdog_8cpp.html#a661de116e4c095c28be59c7f9334d7a1',1,'SIGNAL_CHILD_DEATH():&#160;watchdog.cpp']]],
  ['signal_5fkillself_51',['SIGNAL_KILLSELF',['../process_8cpp.html#a0f1ffd6add45a57cb80935542feabfdd',1,'SIGNAL_KILLSELF():&#160;process.cpp'],['../watchdog_8cpp.html#a0f1ffd6add45a57cb80935542feabfdd',1,'SIGNAL_KILLSELF():&#160;watchdog.cpp']]]
];
