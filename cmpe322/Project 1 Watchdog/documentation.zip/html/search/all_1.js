var searchData=
[
  ['child_5fids_1',['child_ids',['../watchdog_8cpp.html#aa35cd2d50c77535a2e4b67b673313afe',1,'watchdog.cpp']]],
  ['create_5fchild_2',['create_child',['../watchdog_8cpp.html#a720545ebee3a6c7e59844b547818d7d4',1,'watchdog.cpp']]]
];
