var searchData=
[
  ['handle_5fdying_5fchild_3',['handle_dying_child',['../watchdog_8cpp.html#a371bf556039eb7536eb76eb8a6e093de',1,'watchdog.cpp']]],
  ['handle_5fsignal_4',['handle_signal',['../process_8cpp.html#a1ae89049abd6f1aa7782a1b362a9798d',1,'process.cpp']]]
];
