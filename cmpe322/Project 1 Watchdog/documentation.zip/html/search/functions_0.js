var searchData=
[
  ['create_5fchild_31',['create_child',['../watchdog_8cpp.html#a720545ebee3a6c7e59844b547818d7d4',1,'watchdog.cpp']]]
];
